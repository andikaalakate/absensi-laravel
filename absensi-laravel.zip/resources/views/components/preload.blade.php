<div class="preload" id="preload">
    <div class="loader">
        <div class="dot"></div>
    </div>
    <div class="loader">
        <div class="dot"></div>
    </div>
    <div class="loader">
        <div class="dot"></div>
    </div>
    <div class="loader">
        <div class="dot"></div>
    </div>
    <div class="loader">
        <div class="dot"></div>
    </div>
    <div class="loader">
        <div class="dot"></div>
    </div>
</div>